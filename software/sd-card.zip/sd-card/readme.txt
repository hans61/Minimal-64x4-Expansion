##Songs

These songs come from sites like these:

https://vgmrips.net/packs/
https://github.com/shawty/sn76489arduino

They have been converted into a special format for the Minimal.

The conversion is done with this software:

https://github.com/simondotm/vgm-converter

~$ vgmconverter.py "song.vgm" -n -t bbc -q 50 -r "song.vgc"